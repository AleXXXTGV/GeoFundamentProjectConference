import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _39b930d5 = () => interopDefault(import('..\\pages\\About.vue' /* webpackChunkName: "pages/About" */))
const _30218e1a = () => interopDefault(import('..\\pages\\Gallery.vue' /* webpackChunkName: "pages/Gallery" */))
const _3c20a5b2 = () => interopDefault(import('..\\pages\\Hotels.vue' /* webpackChunkName: "pages/Hotels" */))
const _6bdf36be = () => interopDefault(import('..\\pages\\Main.vue' /* webpackChunkName: "pages/Main" */))
const _18bbbeea = () => interopDefault(import('..\\pages\\Register.vue' /* webpackChunkName: "pages/Register" */))
const _3c02288c = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _654036b7 = () => interopDefault(import('..\\pages\\Venue.vue' /* webpackChunkName: "pages/Venue" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/About",
    component: _39b930d5,
    name: "About___en"
  }, {
    path: "/Gallery",
    component: _30218e1a,
    name: "Gallery___en"
  }, {
    path: "/Hotels",
    component: _3c20a5b2,
    name: "Hotels___en"
  }, {
    path: "/Main",
    component: _6bdf36be,
    name: "Main___en"
  }, {
    path: "/Register",
    component: _18bbbeea,
    name: "Register___en"
  }, {
    path: "/ru",
    component: _3c02288c,
    name: "index___ru"
  }, {
    path: "/uz",
    component: _3c02288c,
    name: "index___uz"
  }, {
    path: "/Venue",
    component: _654036b7,
    name: "Venue___en"
  }, {
    path: "/ru/About",
    component: _39b930d5,
    name: "About___ru"
  }, {
    path: "/ru/Gallery",
    component: _30218e1a,
    name: "Gallery___ru"
  }, {
    path: "/ru/Hotels",
    component: _3c20a5b2,
    name: "Hotels___ru"
  }, {
    path: "/ru/Main",
    component: _6bdf36be,
    name: "Main___ru"
  }, {
    path: "/ru/Register",
    component: _18bbbeea,
    name: "Register___ru"
  }, {
    path: "/ru/Venue",
    component: _654036b7,
    name: "Venue___ru"
  }, {
    path: "/uz/About",
    component: _39b930d5,
    name: "About___uz"
  }, {
    path: "/uz/Gallery",
    component: _30218e1a,
    name: "Gallery___uz"
  }, {
    path: "/uz/Hotels",
    component: _3c20a5b2,
    name: "Hotels___uz"
  }, {
    path: "/uz/Main",
    component: _6bdf36be,
    name: "Main___uz"
  }, {
    path: "/uz/Register",
    component: _18bbbeea,
    name: "Register___uz"
  }, {
    path: "/uz/Venue",
    component: _654036b7,
    name: "Venue___uz"
  }, {
    path: "/",
    component: _3c02288c,
    name: "index___en"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
